CREATE TABLE userprofile(
	userid varchar(50) NOT NULL PRIMARY KEY,
	firstname varchar(50) DEFAULT NULL,
	lastname varchar(50) DEFAULT NULL,
	email varchar(50) DEFAULT NULL,
	password varchar(2014) DEFAULT NULL
)
