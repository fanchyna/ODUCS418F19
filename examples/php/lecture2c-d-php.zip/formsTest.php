<form action="greetMe.php" method="post">
    Enter your name: <input type="text" name="nameEntered">
    <input type="submit">
</form>
