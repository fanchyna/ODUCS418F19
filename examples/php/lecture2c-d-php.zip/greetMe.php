Hello, <?php echo $_POST["nameEntered"]; ?>!
