<html>
	<body>
	     <?php echo "Today is: ".date("m/d/y") ?>
	</body>
</html>

